/* Here showDate is Global Varible and Date is built-in  core objects in javascript */
var showDate = new Date();
/*This function will be involved onload event */
function showDateTime()
{
    document.getElementById("showDate").innerHTML
    ="Today's Date and Time is"+ showDate;
}