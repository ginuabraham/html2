//base class
class Product
{
    constructor(productId, productName, 
        productPrice, productDescription)
        {
            this._productId_ = productId;
            this._productName_ = productName;
            this._productPrice_ = productPrice;
            this._productDescription_ = productDescription;
        }
        //function
        printAllProduct()
        {
            var productDetails = 
            `Product Id : ${this._productId_}
             Product Name : ${this._productName_}
             Product Price : ${this._productPrice_}
             Product Description : ${this._productDescription_}
             `;
             return productDetails;
        }
} // end of product class

class Product1 extends Product 
{
//constructor
constructor(productId, productName, productPrice, productDescription, productType)
{
    super(productId, productName, productPrice, productDescription);
    this._productType_ = productType;
   
}
//function
printAllProduct()
{
    let allDetails = super.printAllProduct()+"Product Type :"+this._productType_;
    return allDetails;
}
}//end of product1 class

class Product2 extends Product 
{
//constructor
constructor(productId, productName, productPrice, productDescription, productCategory)
{
    super(productId, productName, productPrice, productDescription);
    this._productCategory_ = productCategory;
  
}
//function
printAllProduct()
{
    let allDetails = super.printAllProduct()+"Product Type :"+this._productCategory_;
    return allDetails;
}
}//end of product2 class

var product1Obj = new Product1("P1","Laptop",50000,"My personal Laptop","Education");
//console.log(product1Obj.printAllProduct());

var product2Obj = new Product2("P2","Refrigerator",20000,"Make things Cool","Home Appliance");
//console.log(product2Obj.printAllProduct());

var product3Obj = new Product1("P3","Washing Machine",40000,"wash cloths","Home Appliance");

var product4Obj = new Product2("P4","Phone",60000,"Calling","Communication");

//creating set object using Set() constructor
let allProducts = new Map();


//CRUD Operations
//Adding to array -->create
allProducts.set(1, product1Obj);
allProducts.set(2, product2Obj);
allProducts.set(3, product3Obj);
allProducts.set(4, product4Obj);

//Reading from an array -->Read
for(var [k,v] of allProducts)
{
    console.log(allProducts.get(k).printAllProduct());
}

console.log("After sorting in ascending order");
//1st way
let sortedMap = new Map([...allProducts.entries()].sort((a,b) => a[1]._productPrice_ - b[1]._productPrice_));

for (var [k,v] of sortedMap)
{
    console.log(allProducts.get(k).printAllProduct());
}

//updating
// let productId = prompt("enter the product id");
//1st way
// let updatedProduct = Array.from(allProducts).find(p => p[1]._productId_ === productId);

// updatedProduct[1]._productName_ = "HP Laptop";


// console.log("After changing product name");
// for (var [k,v] of sortedMap)
// {
//     console.log(allProducts.get(k).printAllProduct());
// }


//deletion
let productId = prompt("enter the product id");
let deletedProduct = Array.from(allProducts).find(p => p[1]._productId_ === productId);

allProducts.delete(deletedProduct[0]);

console.log("After removing product");
//reading from an set ->read
for(var[k, v] of allProducts)
{
    console.log(allProducts.get(k).printAllProduct());
}

