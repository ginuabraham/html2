// constructors in the order of base to derived
class BaseClass
{
    constructor()
    {
        console.log("Base class is called..!");
    }
}
//inheriting from base class
class DerivedClass extends BaseClass
{
    constructor()
    {
        //this is mandatory in derived class
        super();
        console.log("Derived class is called..!");
    }
}
 let  derivedObj = new DerivedClass();
 //op : Base class is called..!
 //     Derived class is called..!

 //parent class or super class
 class Employee
 {
    constructor(id, name, salary)
    {
        this._id_ = id;
        this._name_ = name;
        this._salary_ = salary;
    }
    showDetails()
    {
        let details = `Emp Id: ${this._id_}
                       Name: ${this._name_}
                       Salary: ${this._salary_}
                       `;
            return details;
    }
 }
 //child class or sub class
 class Manager extends Employee
 {
     constructor(id, name, salary, deptName)
     {
        //super keyword is used to call
        //base class constructor to initialize
        //derived class members
        super(id, name, salary);
        this._deptName_ = deptName;
     }
     showDetails()
     {
         return "Department Name: "+this._deptName_+" "+super.showDetails();
     }
 }

 var mgrObj = new Manager(101, "Nihal", 25000, "IT");
 console.log(mgrObj.showDetails());

 class SuperClass
 {
     constructor()
     {
         this._cid_ = 20;
     }
     display()
     {
         return this._cid_;
     }
 }
 class SubClass extends SuperClass
 {
     constructor()
     {
        super(); 
        this._id_ = 10;
     }
     display()
     {
         console.log("instance variable : "+this._id_);
         console.log("super variable : "+super.display());
     }
 }
 let subObj = new SubClass();
 subObj.display();
