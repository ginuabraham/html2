/*For Loop  */
function findFactorial_Forloop(num)
{
    if(num.value == "" || isFinite(num.value) ==false){
        alert('Please enter only Numeric value..!');
    }
    else
    {
        var n =parseInt(num.value);
        var fact = 1;

       for(var i=1;i<=n;i++)
        
        //2)Test Condition
       
        
            fact *= i; //3 Body of the loop
            //4)Incre/Decr
        
            alert("Factorial of "+n+ "is"+fact);
    }
}

/* While */
function findFactorial_Whileloop(num)
{
    if(num.value == "" || isFinite(num.value) == false){
        alert('Please enter only Numeric value..!');
    }
    else
    {
        var n =parseInt(num.value);
       

        // 1)Initialization
        var fact = 1;
        var i=1; 

        //2)Test Condition
        while(i<=n) {
        
            fact *= i; //3 Body of the loop
            i++; //4)Incre/Decr
        }
            alert("Factorial of "+n+ "is"+fact);
    }
}

/*Function with variable number of arguments*/
function function_Arguments(separator)
{
    var result = "";
    for(var i=1; i<arguments.length; i++)
        result += arguments[i] + separator;

        document.write("<h2>" +result+ "</h2>");
}

/*Sum of n numbers*/
function addition()
{
    var sum= 0;
    for(var i=0; i<arguments.length; i++)
    
        sum+=parseInt(arguments[i]);
        return sum;
    
}
document.write("<h3>addition(10,20,30) : "
+addition(10,20,30)+"</h3>");
document.write("<h3>addition(10,20) : "
+addition(10,20)+"</h3>");
document.write("<h3>addition() : "
+addition()+"</h3>");
document.write("<h3>addition(10,20,30,40,50) : "
+addition(10,20,30,40,50)+"</h3>");


