var listofBoys=["Pawan","Kishore","Sai"];
var listofGirls=["Ginu","Shalini","Niharika"];

//Empty
//var numbers=[];
// var courses = new array;

document.write("<h3>"+listofBoys+"</h3");
document.write("<h3>"+listofGirls+"</h3</br>");

document.write("<h3>Displaying Boys using Loops</h3>");
document.write("<h4>Boys Count : "+listofBoys.length+"</h4>");
listofBoys.sort();
for(var i=0; i<listofBoys.length; i++)
document.write(listofBoys[i].bold()+"<br/>");

//Adding at the end of the list
listofBoys.push("Mukund");
document.write("<h3>Displaying Boys after adding Mukund</h3>");
document.write("<h3>"+listofBoys+"</h3>");
document.write("<h3>Displaying Boys using Loops</h3>");
document.write("<h4>Boys Count : "+listofBoys.length+"</h4>");

document.write("<h3>Displaying Boys using Loops Descending Order</h3>");
document.write("<h4>Boys Count : "+listofBoys.length+"</h4>")
listofBoys.reverse();
for(var i=0; i<listofBoys.length; i++)
document.write(listofBoys[i].bold()+"<br/>");


document.write("<h4>Girls Count : "+listofGirls.length+"</h4>");
document.write("<h3>Displaying Girls using Loops</h3>");
listofGirls.sort();
for(var i=0; i<listofGirls.length; i++)
document.write(listofGirls[i].bold()+"<br/>");

//Adding at the beginig of the list
listofGirls.unshift("Shreya");
document.write("<h3>Displaying Girls after adding Shreya</h3>");
document.write("<h3>"+listofGirls+"</h3>");
document.write("<h3>Displaying Girls using Loops</h3>");
document.write("<h4>Girls Count : "+listofGirls.length+"</h4>");

//pop() is used  to remove element from end
//and returns deleted element
listofGirls.pop();
document.write("<h3>"+listofGirls+"</h3>");
document.write("<h4>Girls Count : "+listofGirls.length+"</h4>");

document.write("<h3>Displaying Girls using Loops Descending Order</h3>");
document.write("<h4>Girls Count : "+listofGirls.length+"</h4>");
listofGirls.reverse();
for(var i=0; i<listofGirls.length; i++)
document.write(listofGirls[i].bold()+"<br/>");
 
var listofparticipants=listofGirls.concat(listofBoys);
document.write("<h3>Displaying Final List Of Participants In Ascending Order</h3>");
listofparticipants.sort();
for(var i=0; i<listofparticipants.length; i++)
document.write(listofparticipants[i].bold().italics() +"<br/>");

//concatination
var listofparticipants=listofGirls.concat(listofBoys);
document.write("<h3>Displaying Final List Of Participants In Descending Order</h3>");
listofparticipants.reverse();
for(var i=0; i<listofparticipants.length; i++)
document.write(listofparticipants[i].bold().italics() +"<br/>");

//final list
var finalList = listofparticipants.join(',');
document.write("<h3>Displaying Final List :<br/>  "+finalList+"</h3>" );

//slice
document.write("<h3> First 3 : <br/>"+listofparticipants.slice(0,3) +"</h3>");

//slice will return the selected list of elements from
//an array with deleting it
//even you can add element in between or
//at specified location
//second parameter is optional,and if u mention
//0 means no deletion
//first parameter is start.
//second is deletion count
//third parameter is string array or you can pass 
//individual items. 
listofparticipants.splice(2,2,"Amiksha","Samiksha");
document.write("<h1>"+listofparticipants+"</h1>");


