 // Create class Rectangle
 class Rectangle
 {
     constructor(length,breadth)
     {
         this._length_ = length;
         this._breadth_ = breadth;
     }
     set length(length)
     {
        this._length_ = length;
     }
     get length()
     {
         return this._length_;
     }
     set breadth(breadth)
     {
        this._breadth_ = breadth; 
     }
     get breadth()
     {
         return this._breadth_;
     }

     // non static   
    // calculateArea()
    // {
    //     let area = this._length_  *  this._breadth_ ;
    //      return area;
    // }

    //static function - we require classname to invoke it
    static display()
    {
        return "Area of Rectangle is ";
    }
    //non static function- we require object to invoke it.
    calculateArea()
    {
        let area = this._length_  *  this._breadth_ ;
         return area;
    }
 }

 //creating the rectangle class object
let rectObj1 = new Rectangle();

let length = parseFloat(prompt("Enter length : "));
let breadth = parseFloat(prompt("Enter breadth : "));

//initialising with properties i.e get and set methods
rectObj1.length = length;
rectObj1.breadth = breadth;



//invoking static function using class name 
let area1 = rectObj1.calculateArea();
 console.log("Using properties - "+ Rectangle.display()+" "+area1);


 //2nd way using constructor for initialization
 //creating the Rectangle class Object
 let rectObj2 = new Rectangle(length,breadth);

//invoking static function using class name 
let area2 = rectObj2.calculateArea();




 console.log("Using properties - "+ Rectangle.display()+" "+area2);



// class Square
// {
//     constructor()
//     {
//         console.log("constructor of Square class is called ..!");
//     }
//     calculateArea(s)
//     {
//         let area = s * s;
//         return area;
//     }
// }
// let rectObj = new Square
// let side = parseFloat(prompt("Enter side : "));


// let area = rectObj.calculateArea(side);
// console.log(area);