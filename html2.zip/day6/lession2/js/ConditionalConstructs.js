function checkEvenOrOdd(num)
{
    var result;
    if(num.value==0)
        result="0 IS Neither Even Nor Odd..!";
    else if(num.value %2 == 0)
        result= num.value +" is Even number";
    else
        result=num.value + " is Odd number";
        alert(result);
}

function displayDays(month,year)
{
    var days;
    switch(parseInt(month.value))
    {
        case 1:
        case 3:
        case 5:
        case 7:
        case 8:
        case 10:
        case 12:
        {
            days= 31;
        }
        break;
        case 4:
        case 6:
        case 9:
        case 11:
        {
            days= 30;
        } 
        break;
        case 2:
        {
            if(year.value %4 ==0)
                days= 29;
            else
                days=28;
        }
        break;
        default:
        {
            days=-1;
        }
    }
    if(days == -1)
        alert("error: invalid month..!");
    else
        alert(month.value+" has "+days+"days");
}
function checkNumber(fnum,snum)
{
    parseInt(fnum.value,snum.value);
    var result;
    result= (fnum.value==snum.value) ? "First number is Equals to second number" :
     (fnum.value>snum.value) ? "First number is Greater than second number"
      : "First number is less than second number"  ;
    alert(result);
        
}