function setEmpDetails(eid,name,desig,salary)
{
    this.eid = eid;
    this.name = name;
    this.desig = desig;
    this.salary = salary;

    displayEmpDetails = function(deptName)
    {
        var details = `
Emp Id : ${this.eid} \n
Emp Name : ${this.name} \n
Dept Name : ${deptName} \n
Designation :${this.desig} \n
Salary : ${this.salary} \n
        `;
       // alert(details);

       var empObj = window.open("","Emp Details","width=400px,height=500px");
       var empDetails=`
       <html>
           <head>
               <title>Emp Details</title>
           </head>
           <body >
               <table style="font-family :Monotype Corsiva ;font-size:30px ">
                   <tr align="left">
                       <th>Eid</th>
                       <td>${this.eid}</td>
                   </tr>
                   <tr  align="left">
                       <th>Name</th>
                       <td>${this.name}</td>
                   </tr>
                   <tr align="left">
                       <th>Department Name</th>
                       <td>${deptName}</td>
                   </tr>
                   <tr  align="left">
                       <th>Designation</th>
                       <td>${this.desig}</td>
                   </tr>
                   <tr  align="left">
                       <th>Salary</th>
                       <td>${this.salary}</td>
                   </tr>
               </table>
           </body>
       </html>`;
        empObj.document.write(empDetails);
    }
}