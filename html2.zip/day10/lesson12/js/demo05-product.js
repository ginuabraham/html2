//base class
class Product
{
    constructor(productId, productName, 
        productPrice, productDescription)
        {
            this._productId_ = productId;
            this._productName_ = productName;
            this._productPrice_ = productPrice;
            this._productDescription_ = productDescription;
        }
        //function
        printAllProduct()
        {
            var productDetails = 
            `Product Id : ${this._productId_}
             Product Name : ${this._productName_}
             Product Price : ${this._productPrice_}
             Product Description : ${this._productDescription_}
             `;
             return productDetails;
        }
} // end of product class

class Product1 extends Product 
{
//constructor
constructor(productId, productName, productPrice, productDescription, productType)
{
    super(productId, productName, productPrice, productDescription);
    this._productType_ = productType;
   
}
//function
printAllProduct()
{
    let allDetails = super.printAllProduct()+"Product Type :"+this._productType_;
    return allDetails;
}
}//end of product1 class

class Product2 extends Product 
{
//constructor
constructor(productId, productName, productPrice, productDescription, productCategory)
{
    super(productId, productName, productPrice, productDescription);
    this._productCategory_ = productCategory;
  
}
//function
printAllProduct()
{
    let allDetails = super.printAllProduct()+"Product Type :"+this._productCategory_;
    return allDetails;
}
}//end of product2 class

var product1Obj = new Product1("P1","Laptop",50000,"My personal Laptop","Education");
//console.log(product1Obj.printAllProduct());

var product2Obj = new Product2("P2","Refrigerator",20000,"Make things Cool","Home Appliance");
//console.log(product2Obj.printAllProduct());

var product3Obj = new Product1("P3","Washing Machine",40000,"wash cloths","Home Appliance");

var product4Obj = new Product2("P4","Phone",60000,"Calling","Communication");



let allProducts =[];


//CRUD Operations
//Adding to array -->create
allProducts.push(product1Obj);
allProducts.push(product2Obj);
allProducts.push(product3Obj);
allProducts.push(product4Obj);

//Reading from an array -->Read
for(var product in allProducts)
{
    console.log(allProducts[product].printAllProduct());
}

console.log("After sorting in Ascending order");
allProducts.sort((a,b) => a._productPrice_ - b._productPrice_);

for(var product in allProducts)
{
    console.log(allProducts[product].printAllProduct());
}

//Updating from an array -->update
// let productId = prompt("Enter Product Id");
// for(var product in allProducts)
// {
//     if(allProducts[product]._productId_ === productId)
//     {
//         allProducts[product]._productName_ = "HP Laptop";
//     }
//     else
//     {
//         console.log("Product Id does not Exist");
//     }
// }

// console.log("After changing Product Name");
// //Reading from an array -->Read
// for(var product in allProducts)
// {
//     console.log(allProducts[product].printAllProduct());
// }


//Removing from an array -->Delete
// let productId = prompt("Enter Product Id");
// for(var product in allProducts)
// {
//     if(allProducts[product]._productId_ === productId)
//     {
//         allProducts.splice(product,1);
//     }
// }
// console.log("After removing from array");
// //Reading from an array -->Read
// for(var product in allProducts)
// {
//     console.log(allProducts[product].printAllProduct());
// }