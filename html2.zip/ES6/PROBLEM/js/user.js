class Inventory
{
 getUserIn(){}

 getUserOut(){}

} // end of Inventory class

class User extends Inventory
{
//constructor
constructor(uId, uName, uAge, uCity)
        {
            super();
            this._uId_ = uId;
            this._uName_ = uName;
            this._uAge_ = uAge;
            this._uCity_ = uCity;
        }

//overriding
getUserIn()
{
    console.log('Login successful');
}
getUserOut()
{
    console.log('Logout Successful');
}

        //function
        printAllDetails()
        {
            var userDetails = 
            `User Id : ${this._uId_}
            User Name : ${this._uName_}
            User Age : ${this._uAge_}
            User City : ${this._uCity_}
             `;
             return userDetails;
        }
}

var userObj1 = new User(1002,"rahul",19,"Mumbai");
userObj1.getUserIn();

var userObj2 = new User(1003,"Ram",66,"Pune");
var userObj3 = new User(1001,"Penny",32,"Delhi");
var userObj4 = new User(1004,"Sheldon",30,"Delhi");

let userDetails = new Map();

//CRUD Operations
//Adding to array -->create
userDetails.set(1, userObj1);
userDetails.set(2, userObj2);
userDetails.set(3, userObj3);
userDetails.set(4, userObj4);

//Reading from an array -->Read
for(var [k,v] of userDetails)
{
    console.log(userDetails.get(k).printAllDetails());
}

//updating
// let uId = prompt("enter the User id");
//  let updatedUser = Array.from(userDetails).find(u => u[1]._uId_ == uId);

//  updatedUser[1]._uName_ = "Ginu";
// console.log("After changing User name");
//  for (var [k,v] of userDetails)
// {
//    console.log(userDetails.get(k).printAllDetails());
//  }



//Sorting User Details
 console.log("After sorting in ascending order");

 let sortedMap = new Map([...userDetails.entries()].sort((a,b) => a[1]._uAge_ - b[1]._uAge_));

for (var [k,v] of sortedMap)
 {
     console.log(userDetails.get(k).printAllDetails());
 }

//Deleting the User Object
let uId = prompt("enter the User id");
let deletedUser = Array.from(userDetails).find(u => u[1]._uId_== uId);
if(deletedUser == undefined)
{
    console.log("User not exist");
}
else{
    userDetails.delete(deletedUser[0]);

    console.log("After removing User");
    }
//reading from an set ->read
for(var [k, v] of userDetails)
{
    console.log(userDetails.get(k).printAllDetails());
}
userObj1.getUserOut();
