function calculateBill(frmBillingObj)
{
   // alert('1');
    if(frmBillingObj.checkValidity())
    {   //alert('2');
        var title=frmBillingObj.ddlTitle.value;
        var name =frmBillingObj.txtName.value;
        var carType=frmBillingObj.ddlModel.value;
        var serviceType=frmBillingObj.rbtnService.value;
        var costOfTheVehicle= parseFloat(frmBillingObj.txtCost.value);
        var serviceCharge;
        if(serviceType=="freeservice"){
            serviceCharge=200;
        }
        else if(serviceType=="bodyrepair")
        {
        if(carType=="hatchback")
        {
            serviceCharge=0.15*costOfTheVehicle;
        
        }
        else if(carType=="smallcar")
            serviceCharge=0.10*costOfTheVehicle;
        
        else
        
            serviceCharge=0.18*costOfTheVehicle;
        
        
        }
        var message="Thanks for Visit" +title +"."+name+".cost of service"+serviceCharge;
        alert(message);
}
}