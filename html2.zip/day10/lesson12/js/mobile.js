//base class
class Mobile
{
    constructor(mobileId, mobileName, 
         mobileCost)
        {
            this._mobileId_ = mobileId;
            this._mobileName_ = mobileName;
            this._mobileCost_ = mobileCost;
           
        }
        //function
        printMobileDetail()
        {
            var mobileDetails = 
            `Mobile Id : ${this._mobileId_}
             Mobile Name : ${this._mobileName_}
             Mobile Cost : ${this._mobileCost_}
             `;
             return mobileDetails;
        }
} // end of mobile class

class BasicPhone extends Mobile 
{
//constructor
constructor(mobileId, mobileName, mobileCost,  mobileType)
{
    super(mobileId, mobileName, mobileCost);
    this._mobileType_ = mobileType;
   
}
//function
printMobileDetail()
{
    let allDetails = super.printMobileDetail()+"Mobile Type :"+this._mobileType_;
    return allDetails;
}
}//end of BasicPhone  class

class SmartPhone extends Mobile
{
//constructor
constructor(mobileId, mobileName, mobileCost, mobileType)
{
    super(mobileId, mobileName, mobileCost);
    this._mobileType_ = mobileType;
   
}
//function
printMobileDetail()
{
    let allDetails = super.printMobileDetail()+"Mobile Type :"+this._mobileType_;
    return allDetails;
}
}//end of  SmartPhone class

var mobile1Obj = new BasicPhone("M1", "Basic Phone", 2000, "Nokia");
//console.log(product1Obj.printAllProduct());

var mobile2Obj = new SmartPhone("M2", "Smart Phone", 30000,  "Redmi");
//console.log(product2Obj.printAllProduct());

let allMobiles =[];


//CRUD Operations
//Adding to array -->create
allMobiles.push(mobile1Obj);
allMobiles.push(mobile2Obj);

//Reading from an array -->Read
for(var mobile in allMobiles)
{
    console.log(allMobiles[mobile].printMobileDetail());
}


//Updating from an array -->update
//  let mobileId = prompt("Enter Mobile Id");
//  for(var mobile in allMobiles)
//   {
//    if(allMobiles[mobile]._mobileId_ === mobileId)
//     {
//          allMobiles[mobile]._mobileType_ = "Samsung";
//     }
//    else
//      {
//         console.log("Mobile Id does not Exist");
//      }
//   }

//   console.log("After changing Mobile Type");
//   //Reading from an array -->Read
//   for(var mobile in allMobiles)
//   {
//       console.log(allMobiles[mobile].printMobileDetail());
//   }


//Removing from an array -->Delete
let mobileId = prompt("Enter Mobile Id");
for(var mobile in allMobiles)
{
    if(allMobiles[mobile]._mobileId_ === mobileId)
    {
        allMobiles.splice(mobile,1);
    }
}
console.log("After removing from array");
//Reading from an array -->Read
for(var mobile in allMobiles)
{
    console.log(allMobiles[mobile].printMobileDetail());
}