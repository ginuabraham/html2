// Create class Rectangle
 class Rectangle
 {
     constructor()
    {
        console.log("constructor of Rectangle class is called ..!");
         }
     calculateArea(l,b)
    {
        let area = l * b;
       return area;
    }
 }

 let rectObj = new Rectangle();
 let length = parseFloat(prompt("Enter length : "));
 let breadth = parseFloat(prompt("Enter breadth : "));

 let area = rectObj.calculateArea(length,breadth);
 console.log(area);


class Square
{
    constructor()
    {
        console.log("constructor of Square class is called ..!");
    }
    calculateArea(s)
    {
        let area = s * s;
        return area;
    }
}
let rectObj = new Square();
let side = parseFloat(prompt("Enter side : "));


let area = rectObj.calculateArea(side);
console.log(area);