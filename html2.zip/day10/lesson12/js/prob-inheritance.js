// constructors in the order of base to derived
class Shape
{
    constructor(radius,length,breadth)
    {
        this._radius_ = radius;
        this._length_ = length;
        this._breadth_ = breadth;
     }
     
    calculateArea()
    {
        console.log("This is shape class");
    }   
}
 //inheriting from base class
class Circle extends Shape
 {
     constructor(radius)
     {
         //this is mandatory in derived class
        super(radius);
        
     }
     calculateArea()
     {
        let area = 3.14 * this._radius_  * this._radius_;
          return area;
     }
 }

 class Rectangle extends Shape
{
    constructor(length,breadth)
    {
        //this is mandatory in derived class
        super();
        this._length_ = length;
        this._breadth_ = breadth;
        
    }
    calculateArea()
    {
        let area = this._length_ * this._breadth_;
         return area;
    }
}

//circle
  let  circleObj = new Circle(radius = 5);
  console.log("Area of circle is :"+circleObj.calculateArea());

 //Rectangle
 let  rectangleObj = new Rectangle(length = 5, breadth = 6);
 console.log("Area of rectangle is :"+rectangleObj.calculateArea());
