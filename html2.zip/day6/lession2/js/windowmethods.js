function calculateACircle()
{
   calculate();
}

function calculate()
{
    var radius = parseFloat(prompt("Enter radius"));

    var area = Math.PI * radius * radius;

    alert("Area of Circle is" +area);

    var result = confirm("Do you want to continue ? ");
    if(result==true)
    {
        calculate();
    }
}

/* setInterval() and clearInterval()*/
var intervalObj;
function setIntervalFunc() {
    alert('You Have Started Interval..!');
  intervalObj = setInterval(function()
  {
      alert('Hello World');
  },2000);  
}
function clearIntervalFunc()
{
    clearInterval(intervalObj);
    alert('You have stopped interval..!');
}

/* setTimeOut() and clearTimeOut()*/
var timeOutObj;
function setTimeOutFunc() {
    alert('You Have Started Interval..!');
  timeOutObj = setTimeout(function()
  {
      alert('Hello World');
  },3000);  
}
function clearTimeOutFunc()
{
    clearTimeout(intervalObj);
    alert('You have stopped interval..!');
}

function display()
{
    var message = this.id +" " +this.name+" "+this.desig+" " +this.salary;
    alert(message);
}
//creating object in javascript without class
var emp1 = new Object;
emp1.id = 101;
emp1.name = "Anand";
emp1.desig = "Developer";
emp1.salary = 25000;
//storing ref of one function in another function
emp1.displayEmp = display;
emp1.displayEmp();

var emp2 = new Object;
emp2.id = 102;
emp2.name = "Amit";
emp2.desig = "Tester";
emp2.salary = 35000;
//storing ref of one function in another function
emp2.displayEmp = display;
emp2.displayEmp();

