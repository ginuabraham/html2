var anyType;
document.write("Type: "+typeof(anyType)+" "+"Value: "+anyType);

//string type
anyType="Ginu";
document.write("<br/>Type: "+typeof(anyType)+" "+"Value: "+anyType);

//number type
anyType=1000;
document.write("<br/>Type: "+typeof(anyType)+" "+"Value: "+anyType);

//boolean type
anyType=false;
document.write("<br/>Type: "+typeof(anyType)+" "+"Value: "+anyType);

//object type
anyType=null;
document.write("<br/>Type: "+typeof(anyType)+" "+"Value: "+anyType);